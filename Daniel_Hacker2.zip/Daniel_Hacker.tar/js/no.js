var am_no='279'
var tw_no='120'
var hk_no='076'
if(!window.resUrl)resUrl='https://res1.vuehelp.com/';if(!window.imgUrl)imgUrl='https://img1.vuehelp.com/';